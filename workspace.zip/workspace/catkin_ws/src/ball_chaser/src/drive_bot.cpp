#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "ball_chaser/DriveToTarget.srv"




bool handle_drive_request(ball_chaser::DriveToTarget::Request& req, ball_chaser::DeiveToTarget::Response& res)

{
    ROS_INFO("DriveToTargetRequest received"(float)req.left_wheel_hinge, (float)req.right_wheel_hinge);   
  
    geometry_msgs::Twist motor_command;
    std:vector<float> all_velocity{float req.left_wheel_hinge.linear.x, float req.left_wheel_hinge.angular.z};
    motor_command.linear.x = all_velocity[0];
    motor_command.angular.z = all_velocity[1];
    motor_command_publisher.publish(motor_command);
    
    
int main(int argc, char** argv)
{
    // Initialize a ROS node
    ros::init(argc, argv, "drive_bot");

    // Create a ROS NodeHandle object
    ros::NodeHandle n;

    // Inform ROS master that we will be publishing a message of type geometry_msgs::Twist on the robot actuation topic with a publishing queue size of 10
    motor_command_publisher = n.advertise<geometry_msgs::Twist>("/cmd_vel", 10);


    ros::ServiceServer service = n.advertiseService("drive/ball_chaser/command_robot", handle_drive_request);
    ROS_INFO("Ready to send joint commands");     



    ros::spin();

    return 0;
}
